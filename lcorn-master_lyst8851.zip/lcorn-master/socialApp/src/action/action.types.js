export const IS_AUTHTHENTICATED = 'IS_AUTHTHENTICATED'
export const SET_USER = 'SET_USER'

export const SET_POST = 'SET_POST'
export const ERROR_POST = 'ERROR_POST'