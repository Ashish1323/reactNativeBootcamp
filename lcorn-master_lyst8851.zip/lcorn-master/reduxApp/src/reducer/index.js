import {combineReducers} from 'redux'
import list from './list'

export default combineReducers({
    list,
    
})